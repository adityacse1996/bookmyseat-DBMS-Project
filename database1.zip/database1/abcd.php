<?php
session_start();
$host = "localhost";
$user = "root";
$password = "";
$database = "bookmyseat";
mysql_connect($host,$user,$password);
mysql_select_db($database);
$connection=mysql_connect($host,$user,$password);
if(isset($_POST['delbtn'])){
   // echo $_SESSION['Name'];
 mysql_query("delete from recordbook where Name='".$_SESSION['Name']."'");
    echo "Your Ticket has Successfully Canceled.";
    //include("hello.php");
}

?>